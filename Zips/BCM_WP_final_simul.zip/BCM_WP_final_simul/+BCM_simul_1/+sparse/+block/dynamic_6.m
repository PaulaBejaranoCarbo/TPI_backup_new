function [y, T] = dynamic_6(y, x, params, steady_state, sparse_rowval, sparse_colval, sparse_colptr, T)
  y(46)=y(30)-y(34)*y(33)-y(32)*y(42)*y(35);
end
