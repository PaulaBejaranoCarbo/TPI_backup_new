function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
% function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double  vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double  vector of endogenous variables in the order stored
%                                                    in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double  matrix of exogenous variables (in declaration order)
%                                                    for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double  vector of steady state values
%   params        [M_.param_nbr by 1]        double  vector of parameter values in declaration order
%   it_           scalar                     double  time period for exogenous variables for which
%                                                    to evaluate the model
%
% Output:
%   T           [#temp variables by 1]       double  vector of temporary terms
%

assert(length(T) >= 54);

T = BCM_4shocks_final_est.dynamic_resid_tt(T, y, x, params, steady_state, it_);

T(31) = (-1)/(y(18)*y(18));
T(32) = y(34)*y(33)*T(31);
T(33) = params(17)*y(56)*y(55)*params(2)*(-1)/(y(50)*y(50));
T(34) = T(27)*T(33);
T(35) = (-y(20))/(y(1)*y(1));
T(36) = (-(T(1)*T(35)*2*T(2)));
T(37) = getPowerDeriv(T(3),y(34),1);
T(38) = 1/y(1);
T(39) = (-(T(1)*2*T(2)*T(38)));
T(40) = (-y(51))/(y(20)*y(20));
T(41) = 2*y(51)/y(20);
T(42) = T(40)*T(41);
T(43) = 1/y(20);
T(44) = getPowerDeriv(y(2)*y(31),params(1),1);
T(45) = getPowerDeriv(y(2)*y(31),params(1)-1,1);
T(46) = params(5)*getPowerDeriv(y(22),params(4),1);
T(47) = getPowerDeriv(y(22),1-params(1),1);
T(48) = getPowerDeriv(y(22),(-params(1)),1);
T(49) = getPowerDeriv(y(5),params(14),1);
T(50) = (-y(55))/(y(33)*y(33));
T(51) = 1/y(33);
T(52) = (-((1-params(12))*y(53)*y(52)))/(y(55)*y(55));
T(53) = params(17)*params(2)*1/y(50)*y(56);
T(54) = params(17)*y(55)*params(2)*1/y(50);

end
