function [y, T] = static_6(y, x, params, sparse_rowval, sparse_colval, sparse_colptr, T)
  T(27)=log(y(2));
  y(23)=log(y(10))-T(27);
  y(22)=log(y(9))-T(27);
  y(21)=log(y(3));
  y(20)=T(27);
  y(18)=y(2)-y(6)*y(5)-y(4)*y(14)*y(7);
end
