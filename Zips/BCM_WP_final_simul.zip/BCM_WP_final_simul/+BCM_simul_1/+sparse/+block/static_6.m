function [y, T] = static_6(y, x, params, sparse_rowval, sparse_colval, sparse_colptr, T)
  y(18)=y(2)-y(6)*y(5)-y(4)*y(14)*y(7);
end
