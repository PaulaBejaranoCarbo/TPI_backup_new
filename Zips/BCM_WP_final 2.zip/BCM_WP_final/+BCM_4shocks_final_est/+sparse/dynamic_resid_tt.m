function [T_order, T] = dynamic_resid_tt(y, x, params, steady_state, T_order, T)
if T_order >= 0
    return
end
T_order = 0;
if size(T, 1) < 30
    T = [T; NaN(30 - size(T, 1), 1)];
end
T(1) = params(17)/2;
T(2) = y(35)/y(3)-1;
T(3) = 1-T(1)*T(2)^2;
T(4) = (params(19)-1)/params(19);
T(5) = params(5)*y(37)^params(4);
T(6) = 1/params(2);
T(7) = y(80)/y(48);
T(8) = (1-params(12))*y(78)*y(71)/y(80)+1-y(79);
T(9) = (y(4)*y(46))^params(1);
T(10) = y(37)^(1-params(1));
T(11) = y(11)^params(14);
T(12) = y(37)^(-params(1));
T(13) = (y(4)*y(46))^(params(1)-1);
T(14) = y(40)*params(1)*T(13);
T(15) = 0.2*(1-params(15))^2;
T(16) = (1-params(15))^3*0.15;
T(17) = (1-params(15))^4*0.1;
T(18) = (1-params(15))^5*0.075;
T(19) = 0.075*(1-params(15))^6;
T(20) = (1-params(15))^7*0.05;
T(21) = 0.05*(1-params(15))^8;
T(22) = 0.05*(1-params(15))^9;
T(23) = 0.05*(1-params(15))^10;
T(24) = 1/y(33);
T(25) = params(17)*y(35)/y(3);
T(26) = params(17)*y(80)*params(2)*1/y(65)*y(81);
T(27) = (y(67)/y(35))^2;
T(28) = y(67)/y(35)-1;
T(29) = T(3)^y(49);
T(30) = T(3)-T(2)*T(25);
end
