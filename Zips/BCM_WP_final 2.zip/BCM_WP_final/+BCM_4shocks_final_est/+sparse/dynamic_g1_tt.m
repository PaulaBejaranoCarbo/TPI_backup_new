function [T_order, T] = dynamic_g1_tt(y, x, params, steady_state, T_order, T)
if T_order >= 1
    return
end
[T_order, T] = BCM_4shocks_final_est.sparse.dynamic_resid_tt(y, x, params, steady_state, T_order, T);
T_order = 1;
if size(T, 1) < 54
    T = [T; NaN(54 - size(T, 1), 1)];
end
T(31) = (-1)/(y(33)*y(33));
T(32) = y(49)*y(48)*T(31);
T(33) = params(17)*y(81)*y(80)*params(2)*(-1)/(y(65)*y(65));
T(34) = T(27)*T(33);
T(35) = (-y(35))/(y(3)*y(3));
T(36) = (-(T(1)*T(35)*2*T(2)));
T(37) = getPowerDeriv(T(3),y(49),1);
T(38) = 1/y(3);
T(39) = (-(T(1)*2*T(2)*T(38)));
T(40) = (-y(67))/(y(35)*y(35));
T(41) = 2*y(67)/y(35);
T(42) = T(40)*T(41);
T(43) = 1/y(35);
T(44) = getPowerDeriv(y(4)*y(46),params(1),1);
T(45) = getPowerDeriv(y(4)*y(46),params(1)-1,1);
T(46) = params(5)*getPowerDeriv(y(37),params(4),1);
T(47) = getPowerDeriv(y(37),1-params(1),1);
T(48) = getPowerDeriv(y(37),(-params(1)),1);
T(49) = getPowerDeriv(y(11),params(14),1);
T(50) = (-y(80))/(y(48)*y(48));
T(51) = 1/y(48);
T(52) = (-((1-params(12))*y(78)*y(71)))/(y(80)*y(80));
T(53) = params(17)*params(2)*1/y(65)*y(81);
T(54) = params(17)*y(80)*params(2)*1/y(65);
end
