function [T_order, T] = static_g1_tt(y, x, params, T_order, T)
if T_order >= 1
    return
end
[T_order, T] = BCM_4shocks_final_est.sparse.static_resid_tt(y, x, params, T_order, T);
T_order = 1;
if size(T, 1) < 24
    T = [T; NaN(24 - size(T, 1), 1)];
end
T(19) = getPowerDeriv(y(14)*y(4),params(1),1);
T(20) = getPowerDeriv(y(14)*y(4),params(1)-1,1);
T(21) = params(5)*getPowerDeriv(y(5),params(4),1);
T(22) = getPowerDeriv(y(5),1-params(1),1);
T(23) = getPowerDeriv(y(5),(-params(1)),1);
T(24) = getPowerDeriv(y(11),params(14),1);
end
