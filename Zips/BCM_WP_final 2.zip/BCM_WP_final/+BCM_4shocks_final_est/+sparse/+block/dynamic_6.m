function [y, T] = dynamic_6(y, x, params, steady_state, sparse_rowval, sparse_colval, sparse_colptr, T)
  T(27)=log(y(34));
  y(55)=log(y(42))-T(27);
  y(54)=log(y(41))-T(27);
  y(53)=log(y(35));
  y(52)=T(27);
  y(50)=y(34)-y(38)*y(37)-y(36)*y(46)*y(39);
end
