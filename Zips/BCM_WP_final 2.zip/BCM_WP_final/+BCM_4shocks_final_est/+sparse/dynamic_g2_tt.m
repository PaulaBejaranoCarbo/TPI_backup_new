function [T_order, T] = dynamic_g2_tt(y, x, params, steady_state, T_order, T)
if T_order >= 2
    return
end
[T_order, T] = BCM_4shocks_final_est.sparse.dynamic_g1_tt(y, x, params, steady_state, T_order, T);
T_order = 2;
if size(T, 1) < 62
    T = [T; NaN(62 - size(T, 1), 1)];
end
T(55) = (-((-y(35))*(y(3)+y(3))))/(y(3)*y(3)*y(3)*y(3));
T(56) = (-(T(1)*(2*T(2)*T(55)+T(35)*2*T(35))));
T(57) = getPowerDeriv(T(3),y(49),2);
T(58) = T(3)^(y(49)-1);
T(59) = getPowerDeriv(y(4)*y(46),params(1),2);
T(60) = getPowerDeriv(y(37),1-params(1),2);
T(61) = getPowerDeriv(y(11),params(14),2);
T(62) = getPowerDeriv(y(4)*y(46),params(1)-1,2);
end
