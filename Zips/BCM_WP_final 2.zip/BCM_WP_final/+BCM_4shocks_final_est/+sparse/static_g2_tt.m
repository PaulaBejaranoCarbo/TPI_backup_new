function [T_order, T] = static_g2_tt(y, x, params, T_order, T)
if T_order >= 2
    return
end
[T_order, T] = BCM_4shocks_final_est.sparse.static_g1_tt(y, x, params, T_order, T);
T_order = 2;
if size(T, 1) < 28
    T = [T; NaN(28 - size(T, 1), 1)];
end
T(25) = getPowerDeriv(y(14)*y(4),params(1),2);
T(26) = getPowerDeriv(y(5),1-params(1),2);
T(27) = getPowerDeriv(y(11),params(14),2);
T(28) = getPowerDeriv(y(14)*y(4),params(1)-1,2);
end
