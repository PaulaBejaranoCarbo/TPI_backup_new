function y = set_auxiliary_variables(y, x, params)
%
% Computes auxiliary variables of the static model
%
y(24)=y(10);
y(25)=y(24);
y(26)=y(25);
y(27)=y(26);
y(28)=y(27);
y(29)=y(28);
y(30)=y(29);
y(31)=y(30);
y(32)=y(31);
end
